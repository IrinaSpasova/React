# Star Match Game

```
npm i
```

```
npm start
```

Server will run on port 4242 by default.
